# veggie detection > 2025-09-29 1:25pm
https://universe.roboflow.com/academic-bafvt/veggie-detection-uilmy

Provided by a Roboflow user
License: CC BY 4.0

